<?php
require_once 'Business/Item.php';

interface ICustomerItemProxy
{
	/**
	 * @param $name
	 * @return int
	 */
	function getNumOfItemByName($name);

	/**
	 * get brief info of items associated with $name
	 * @param string $name
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByName($name,$pageNo,$pageSize);

	/**
	 * @param $id category's id
	 * @return int
	 */
	function getNumOfItemByCategoryId($id);

	/**
	 * @param $id category's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByCategoryId($id,$pageNo,$pageSize);

	/**
	 * get an instance of Item from database with all its members
	 * @param int $id
	 * @return DrugItem an instance of DrugItem if success, NULL if failed.
	 */
	function loadItem($id);
}

interface IStoreItemProxy
{
	/**
	 * get an instance of Item from database with all its members
	 * @param int $id
	 * @return DrugItem an instance of DrugItem if success, NULL if failed.
	 */
	function loadItem($id);

	/**
	 * save the item info to database with all it's members.
	 * if the item does not have an id, then insert it and fill its id with retrn value.
	 * if a member has not an id,then insert and fill it with the return value.
	 * @param DrugItem $item
	 * @return bool true if success, false otherwise.
	 */
	function saveItem(DrugItem $item);

	/**
	 * @param $id int item's id
	 * @return bool true if success and false otherwise.
	 */
	function putOn($id);

	/**
	 * @param $id
	 * @return bool true if success and false otherwise.
	 */
	function putOff($id);

	/**
	 * @param $id store's id
	 * @return int
	 */
	function getNumOfItemByStoreId($id,$pageNo,$pageSize);

	/**
	 * @param $id store's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByStoreId($id);
}

interface IManagerItemProxy
{
	/**
	 * @param $name
	 * @return int
	 */
	function getNumOfItemByName($name);
	/**
	 * get brief info of items associated with $name
	 * @param string $name
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByName($name,$pageNo,$pageSize);

	/**
	 * get an instance of Item from database with all its members
	 * @param int $id
	 * @return DrugItem an instance of DrugItem if success, NULL if failed.
	 */
	function loadItem($id);

	/**
	 * @param $id
	 * @return bool true if success and false otherwise.
	 */
	function putOff($id);

	/**
	 * @param $id store's id
	 * @return int
	 */
	function getNumOfItemByStoreId($id,$pageNo,$pageSize);
	/**
	 * @param $id store's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByStoreId($id);

	/**
	 * @param $id category's id
	 * @return int
	 */
	function getNumOfItemByCategoryId($id);
	/**
	 * @param $id category's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByCategoryId($id,$pageNo,$pageSize);
}

/**
 * interface of ItemProxy
 * @author johns
 *
 */
interface IItemProxy extends  ICustomerItemProxy,IStoreItemProxy,IManagerItemProxy
{
	/**
	 * @param $name
	 * @return int
	 */
	function getNumOfItemByName($name);
	
	/**
	 * get an instance of Item from database with all its members
	 * @param int $id
	 * @return DrugItem an instance of DrugItem if success, NULL if failed.
	 */
	function loadItem($id);
	
	/**
	 * save the item info to database with all it's members.
	 * if the item does not have an id, then insert it and fill its id with retrn value.
	 * if a member has not an id,then insert and fill it with the return value.
	 * @param DrugItem $item
	 * @return bool true if success, false otherwise.
	 */
	function saveItem(DrugItem $item);

	/**
	 * @param $id int item's id
	 * @return bool true if success and false otherwise.
	 */
	function putOn($id);

	/**
	 * @param $id
	 * @return bool true if success and false otherwise.
	 */
	function putOff($id);

	/**
	 * @param $id store's id
	 * @return int
	 */
	function getNumOfItemByStoreId($id,$pageNo,$pageSize);
	/**
	 * @param $id store's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByStoreId($id);

	/**
	 * @param $id category's id
	 * @return int
	 */
	function getNumOfItemByCategoryId($id);
	/**
	 * @param $id category's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByCategoryId($id,$pageNo,$pageSize);
	
}

/**
 * sample ItemProxy
 * @author johns
 *
 */
class SItemProxy implements IItemProxy
{
	public function getItemsByName($name,$pageNo,$pageSize)
	{
		$arr=array();
		$num=5;
		for($i=0;$i<$num;$i++)
		{
			$obj=new BriefItemInfo();
			$obj->mName=$name;
			$obj->mID=rand(10,100);
			$arr+=array($obj);
		}
		return $arr;
	}
	
	public function loadItem($id)
	{
		$factory=new ItemFactory();
		$item=$factory->getInstance();
		$item->mName="sample";
		$item->mId=$id;
		return $item;
	}
	
	public function saveItem(DrugItem $item)
	{
		if(isset($item->mId)) return true;
		else $item->mId=mt_rand(1000,10000);
		return true;
	}

	/**
	 * @param $name
	 * @return int
	 */
	function getNumOfItemByName($name)
	{
		return 5;
	}

	/**
	 * @param $id int item's id
	 * @return bool true if success and false otherwise.
	 */
	function putOn($id)
	{
		return true;
	}

	/**
	 * @param $id
	 * @return bool true if success and false otherwise.
	 */
	function putOff($id)
	{
		return true;
	}

	/**
	 * @param $id store's id
	 * @return int
	 */
	function getNumOfItemByStoreId($id, $pageNo, $pageSize)
	{
		return 5;
	}

	/**
	 * @param $id store's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByStoreId($id)
	{
		$arr=array();
		$num=5;
		for($i=0;$i<$num;$i++)
		{
			$obj=new BriefItemInfo();
			$obj->mName="sample";
			$obj->mID=$id;
			$arr+=array($obj);
		}
		return $arr;
	}

	/**
	 * @param $id category's id
	 * @return int
	 */
	function getNumOfItemByCategoryId($id)
	{
		return 5;
	}

	/**
	 * @param $id category's id
	 * @return array an array of BriefItemInfo
	 */
	function getItemsByCategoryId($id, $pageNo, $pageSize)
	{
		$arr=array();
		$num=5;
		for($i=0;$i<$num;$i++)
		{
			$obj=new BriefItemInfo();
			$obj->mName="sample";
			$obj->mID=rand(100,1000);
			$arr+=array($obj);
		}
		return $arr;
	}
	
}

class ItemProxyFactory
{
	/**
	 * @return ICustomerItemProxy
	 */
	public function getCustomerItemProxy()
	{
		return new SItemProxy();
	}

	/**
	 * @return IStoreItemProxy
	 */
	public function getStoreItemProxy()
	{
		return new SItemProxy();
	}

	/**
	 * @return IManagerItemProxy
	 */
	public function getManagerItemProxy()
	{
		return new SItemProxy();
	}
}