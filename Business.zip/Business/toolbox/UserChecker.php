<?php

interface IUserChecker
{
	/**
	 * login
	 * @param string $uid user's id
	 * @param string $pass password
	 * @return string 128bit of token string if success or "0" if fail.
	 */
	function login($uid,$pass);
	/**
	 * register a user
	 * @param string $name register name
	 * @param string $pass password
	 * @return integer uid if success, -1 otherwise.
	 */
	function register($name,$pass);
	/**
	 * check access using token string
	 * @param string $uid user's id
	 * @param string $token the token string
	 * @return string "success" if success,"timeout" if exceed time limit,"fail" if failed.
	 */
	function checkAccess($uid,$token);
}


/**
 * sample CustomerChecker
 * @author johns
 *
 */
class SCunstomerChecker implements IUserChecker
{
	public function login($uid,$pass)
	{
		echo "sample customerChecker.login invoked\n";
		return md5($uid.$pass);
	}
	public function register($name,$pass)
	{
		echo "sample customerChecker.register invoked\n";
	}
	public function checkAccess($uid,$token)
	{
		echo "sample customerChecker.chekcAccess invoked\n";
	}
}

/**
 * sample StoreChecker
 * @author johns
 *
 */
class SStoreChecker implements IUserChecker
{
	public function login($uid,$pass)
	{
		echo "sample vendorChecker.login invoked\n";
		return md5($uid.$pass);
	}
	public function register($name,$pass)
	{
		echo "sample vendorChecker.register invoked\n";
	}
	public function checkAccess($uid,$token)
	{
		echo "sample vendorChecker.chekcAccess invoked\n";
	}
}

/**
 * sample ManagerChecker
 * @author johns
 *
 */
class SManagerChecker implements IUserChecker
{
	public function login($uid,$pass)
	{
		echo "sample managerChecker.login invoked\n";
		return md5($uid.$pass);
	}
	public function register($name,$pass)
	{
		echo "sample managerChecker.register invoked\n";
	}
	public function checkAccess($uid,$token)
	{
		echo "sample managerChecker.chekcAccess invoked\n";
	}
}

/**
 * UserChecker's Factory
 * @author johns
 *
 */
class UserCheckerFactory
{
	/**
	 * get a UserChecker of $type
	 * @param string $type : one of "CUSTOMER","STORE","MANAGER"
	 * @return instance of IUserChecker
	 */
	public function getInstanceOfType($type)
	{
		switch($type)
		{
			case "CUSTOMER":
				echo "customer userchecker\n";
				return new SCunstomerChecker();
				break;
			case "Store":
				echo "vendor userchecker\n";
				return new SStoreChecker();
				break;
			case "MANAGER":
				echo "manager userchecker\n";
				return new SManagerChecker();
				break;
			default:
				return new CustomerChecker();
				break;
		}
	}
}